一.如果你是图标使用者:
如有需要你可以下载(http://repo.niceios.com/debs/Alkaline.zip)Alkaline的电池图标文件解压到这里
Library/NiceiOS/nicepower[或nicebarx]/icons/batteryicons 即可

二.如果你是图标制作者:
1.如果是彩色图标(不需要插件黑白自适应图标颜色)文件请命名为 
(1)充电时:Color_BatteryChargingInsides_xx 如: Color_BatteryChargingInsides_70@2x.png
(2)非充电时:Color_BatteryDrainingInsides_xx 如: Color_BatteryDrainingInsides_70@2x.png
2.如果是黑白图标(需要插件自适应颜色)文件请命名为 
(1)充电时:Black_BatteryChargingInsides_xx 如:Black_BatteryChargingInsides_70@2x.png
(2)非充电时:Black_BatteryDrainingInsides_xx 如:Black_BatteryDrainingInsides_70@2x.png


一.If you are an icon user:
If needed, you can download(http://repo.niceios.com/debs/Alkaline.zip) the battery icon file for the Alkaline and unzip it here
Library/NiceiOS/nicepower[or nicebarx]/icons/batteryicons 

二.If you're an icon maker:
1.If it is a color icon (do not need the plugin black and white adaptive icon color) the file request name
(1)When charging:Color_BatteryChargingInsides_xx eg: Color_BatteryChargingInsides_70@2x.png
(2)Not charging:Color_BatteryDrainingInsides_xx eg: Color_BatteryDrainingInsides_70@2x.png
2.If it is a black and white icon (plugin adaptive color required) the file request name 
(1)When charging:Black_BatteryChargingInsides_xx eg:Black_BatteryChargingInsides_70@2x.png
(2)Not charging:Black_BatteryDrainingInsides_xx eg:Black_BatteryDrainingInsides_70@2x.png